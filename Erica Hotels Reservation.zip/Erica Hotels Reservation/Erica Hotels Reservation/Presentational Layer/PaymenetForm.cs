﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Erica_Hotels_Reservation.Presentational_Layer
{
    public partial class PaymenetForm : Form
    {
        //private ConfirmationForm confirmationForm = new ConfirmationForm();
        private GuestDetailsForm guestDetailsForm = new GuestDetailsForm();
        private MainForm mainForm = new MainForm();
        public PaymenetForm()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
            
        }

        private void addRes_Click(object sender, EventArgs e)
        {
            this.Hide();
            guestDetailsForm.Show();
        }

        private void viewRep_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainForm.Show();
        }

        private void viewGuests_Click(object sender, EventArgs e)
        {
            this.Hide();
            //confirmationForm.Show();

        }

        private void PaymenetForm_Load(object sender, EventArgs e)
        {

        }
    }
}
