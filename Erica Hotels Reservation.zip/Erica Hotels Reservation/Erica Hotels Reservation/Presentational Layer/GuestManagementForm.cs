﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using Erica_Hotels_Reservation.Properties;
using System.Windows.Forms;

namespace Erica_Hotels_Reservation.Presentational_Layer
{
    public partial class GuestManagementForm : Form
    {
        
        //DataTable table = new DataTable();
        private string connection = Settings.Default.ericaHotelReservationsConnectionString;
        //private BindingSource reservationsBindingSource = 
        //dataGridview2 = new DataGridView();
        private SqlDataAdapter dataAdapter = new SqlDataAdapter();

        private MainForm mainForm = new MainForm();
        public bool reservationFormClosed = false;


        public GuestManagementForm()
        {
            InitializeComponent();

        }
        private void GuestManagementForm_Load(object sender, EventArgs e)
        {
            dataGridView3.DataSource = guestBindingSource;
            GetData("select * from Guest");
            dataGridView3.ReadOnly = true;
            //savebutton1.Enabled = false;
           

            //this.reservationsTableAdapter.Fill(this.ericaHotelReservationsDataSet2.Reservations);


        }

        private void backButton_Click(object sender, EventArgs e)
        {

            this.Hide();
            mainForm.Show();

        }

 
        private void GetData(string selectCommand)
        {
            try
            {
                
                dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                guestBindingSource.DataSource = table;
            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message, "Error");
                return;
            }


        }

   

        private void button1_Click_1(object sender, EventArgs e)
        {
            dataAdapter.Update((DataTable)guestBindingSource.DataSource);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainForm.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            //savebutton1.Enabled = true;
            dataGridView3.ReadOnly = false;
            GetData(dataAdapter.SelectCommand.CommandText);
        }
        //private void GuestManagementForm_Load(object sender, EventArgs e)
        //{
        //    // TODO: This line of code loads data into the 'ericaHotelReservationsDataSet3.Guest' table. You can move, or remove it, as needed.
        //    this.guestTableAdapter.Fill(this.ericaHotelReservationsDataSet3.Guest);

        //}
    }
}
