﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Erica_Hotels_Reservation.Bussiness_Logic_Layer;


namespace Erica_Hotels_Reservation.Presentational_Layer
{
    public partial class MainForm : Form
    {
        //private bool FixedWidth = false;
        private RoomSelectionForm roomSelectionForm;
        private ReservationManagementForm reservationManagementForm;
        private ViewGuestsForm viewGuestForm;
        private Report viewReport;
        private GuestController guestController;
        private RoomController roomController;
        //private ReservationManagementForm reservationMngtController;
        private ReservationController reservationController;
        private AvailabilityController checkDtsContoller;


        private string today;
        private string checkInDate;
        private string checkOutDate;

        public Report currentReportSelection
        {
            get { return viewReport; }
            set { viewReport = value; }
        }
        public RoomSelectionForm currentRoomSelectionForm
        {
            get
            { 
                return roomSelectionForm; 
            }
            set
            {
                roomSelectionForm = value; 
            }
        }
        public ReservationManagementForm currentReservationManagementForm
        {
            get
            {
                return reservationManagementForm;
            }
            set
            {
                reservationManagementForm = value;
            }
        }
        public ViewGuestsForm currentViewGuestForm
        {
            get { return viewGuestForm; }
            set {viewGuestForm = value; }
        }
        
        public MainForm()
        {
            InitializeComponent();
            //resListView.Refresh();
            guestController  = new GuestController();
            roomController = new RoomController();
            reservationController = new ReservationController();
            checkDtsContoller = new AvailabilityController();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
         
            this.WindowState = FormWindowState.Normal;
            setUpReservationListView();

            //this.reportViewer1.RefreshReport();
        }

        private void setUpReservationListView()
        {
            
  
            ListViewItem allReservations;
            Collection<Reservations> reservations = null;
            reservations = reservationController.FindReservation();
            //Add reservation details to each ListView item

            foreach (Reservations aReservation in reservations)
            {
                allReservations = new ListViewItem(aReservation.guestNm);
                allReservations.SubItems.Add(aReservation.RrmID);
                allReservations.SubItems.Add(aReservation.chkIn.ToString());
                allReservations.SubItems.Add(aReservation.chkOut.ToString());
                allReservations.SubItems.Add(aReservation.resStatus);

                resListView.Items.Add(allReservations);     
            }
            resListView.Refresh();
        }

        private void addRes_Click(object sender, EventArgs e)
        {
            if (roomSelectionForm == null)
            {
                CreateNewRoomSelectForm();
            }
            if (roomSelectionForm.roomFormClosed)
            {
                CreateNewRoomSelectForm();
            }
            roomSelectionForm.Show();
            this.Hide();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (roomSelectionForm == null)
            {
                CreateNewRoomSelectForm();
            }
            if (roomSelectionForm.roomFormClosed)
            {
                CreateNewRoomSelectForm();
            }
            roomSelectionForm.Show();
            this.Hide();
        }
        private void CreateNewReportForm() 
        {
            viewReport = new Report();
            viewReport.StartPosition = FormStartPosition.CenterScreen;
        }
        private void CreateNewRoomSelectForm()
        {
            roomSelectionForm = new RoomSelectionForm(roomController);
            roomSelectionForm.StartPosition = FormStartPosition.CenterScreen;
        }


        private void checkAvailabilitybutton_Click(object sender, EventArgs e)
        {
            Collection<RoomAvailability> chckDates = null;
            //Collection<RoomAvailability> match = null;
            //RoomAvailability chkDatz = new RoomAvailability();
            int count = 0;

      
            chckDates = checkDtsContoller.CheckRooms();
            today = DateTime.Today.ToShortDateString();
            checkInDate = dateTimePicker1.Value.ToShortDateString();
            checkOutDate = dateTimePicker2.Value.ToShortDateString();

            if (checkInDate.CompareTo(today) < 0 || checkOutDate.CompareTo(today) < 0)
            {
                MessageBox.Show("YOU CAN NOT BOOK FOR A DATE EARLIER THAN TODAY", "Erica Hotel Room Availability", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }   
            else if (checkOutDate.CompareTo(checkInDate) < 0)
            {
                MessageBox.Show("DATE MISMATCH: CHECKOUT DATE IS EARLIER THEN CHECKIN DATE", "Erica Hotel Room Availability", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else 
            {

                foreach (RoomAvailability aRoomDate in chckDates)
                {

                    //MessageBox.Show("this is hard" + aRoomDate.chkRmAvail.ToShortDateString());
                    
                    if (aRoomDate.chkRmAvail.ToShortDateString().CompareTo(checkInDate) == 0 )
                    {

                        count += 1;

                    }
                    if (aRoomDate.chkRmAvail.ToShortDateString().CompareTo(checkOutDate) == 0) 
                    {
                        count += 1;
                    }
                    
                }
                //MessageBox.Show("this is hard" + match.ToString());
                
                if ( count == 0)
                {
                    MessageBox.Show("ROOMS ARE AVAILABLE FOR THE SELECTED DATES: CLICK ADD RESERVATION TO MAKE A BOOKING.", "Erica Hotel Room Availability", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    //MessageBox.Show
                    MessageBox.Show("No Rooms Available For Selected Period of Time.", "Erica Hotel Room Availability", MessageBoxButtons.OK, MessageBoxIcon.Information);
          
                }
              
 
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (reservationManagementForm == null)
            {
                CreateNewReservationManagementForm();
            }
            if (reservationManagementForm.reservationFormClosed)
            {
                CreateNewReservationManagementForm();
            }
            reservationManagementForm.Show();
            this.Hide();
        }
        private void CreateNewViewGuestForm() 
        {
            viewGuestForm = new ViewGuestsForm();
            viewGuestForm.StartPosition = FormStartPosition.CenterScreen;
        }
        private void CreateNewReservationManagementForm()
        {
            reservationManagementForm = new ReservationManagementForm();
            reservationManagementForm.StartPosition = FormStartPosition.CenterScreen;
        }

        private void viewGuests_Click(object sender, EventArgs e)
        {
            if (viewGuestForm == null)
            {
                CreateNewViewGuestForm();
            }
            if (viewGuestForm.viewGuestFormClosed)
            {
                CreateNewViewGuestForm();
            }
            viewGuestForm.Show();
            this.Hide();
        }

        private void usersToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (viewReport == null)
            {
                CreateNewReportForm();
            }
            if (viewReport.viewReportFormClosed)
            {
                CreateNewReportForm();
            }
            viewReport.Show();
            this.Hide();

        }

        private void viewRep_Click(object sender, EventArgs e)
        {
            if (viewReport == null)
            {
                CreateNewReportForm();
            }
            if (viewReport.viewReportFormClosed)
            {
                CreateNewReportForm();
            }
            viewReport.Show();
            this.Hide();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (reservationManagementForm == null)
            {
                CreateNewReservationManagementForm();
            }
            if (reservationManagementForm.reservationFormClosed)
            {
                CreateNewReservationManagementForm();
            }
            reservationManagementForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (reservationManagementForm == null)
            {
                CreateNewReservationManagementForm();
            }
            if (reservationManagementForm.reservationFormClosed)
            {
                CreateNewReservationManagementForm();
            }
            reservationManagementForm.Show();
            this.Hide();
        }



    }
}
