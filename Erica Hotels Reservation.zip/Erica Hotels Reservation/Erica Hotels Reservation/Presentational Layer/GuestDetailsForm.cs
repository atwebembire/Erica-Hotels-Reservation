﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Erica_Hotels_Reservation.Bussiness_Logic_Layer;

namespace Erica_Hotels_Reservation.Presentational_Layer
{
    public partial class GuestDetailsForm : Form
    {
        private MainForm mainForm = new MainForm();
        private GuestManagementForm findGuest = new GuestManagementForm();
        private RoomController rmController = new RoomController();
        private RoomSelectionForm roomSelectionForm;
        private PaymenetForm paymentForm = new PaymenetForm();
        public GuestDetailsForm()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            roomSelectionForm = new RoomSelectionForm(rmController);
            roomSelectionForm.Show();

        }

        private void GuestDetailsForm_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Room aRoom = new Room();
            Reservations aReservation = new Reservations();
            Guest aGuest = new Guest();
            Payments aPayment = new Payments();
            //aGuest
            this.Hide();
            paymentForm.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            findGuest.Show();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainForm.Show();
            
        }
    }
}
