﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Erica_Hotels_Reservation.Presentational_Layer
{
    public partial class ConfirmationForm : Form
    {
        private PaymenetForm payment = new PaymenetForm();
        private MainForm mainForm = new MainForm();

        public ConfirmationForm()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            payment.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainForm.Show();
            
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainForm.Show();

        }

        private void ConfirmationForm_Load(object sender, EventArgs e)
        {

        }
    }
}
