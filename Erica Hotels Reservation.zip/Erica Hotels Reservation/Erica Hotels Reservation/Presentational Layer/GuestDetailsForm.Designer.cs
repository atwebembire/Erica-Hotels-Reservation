﻿namespace Erica_Hotels_Reservation.Presentational_Layer
{
    partial class GuestDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lanameBox = new System.Windows.Forms.TextBox();
            this.codetextBox = new System.Windows.Forms.TextBox();
            this.faxtextBox = new System.Windows.Forms.TextBox();
            this.wphontextBox = new System.Windows.Forms.TextBox();
            this.cellPhontextBox = new System.Windows.Forms.TextBox();
            this.adultstextBox = new System.Windows.Forms.TextBox();
            this.undertextBox7 = new System.Windows.Forms.TextBox();
            this.kidstextBox6 = new System.Windows.Forms.TextBox();
            this.emailtextBox = new System.Windows.Forms.TextBox();
            this.streettextBox = new System.Windows.Forms.TextBox();
            this.citytextBox = new System.Windows.Forms.TextBox();
            this.fcounttextBox = new System.Windows.Forms.TextBox();
            this.faddtextBox = new System.Windows.Forms.TextBox();
            this.fnameTextBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cancelButton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(267, -2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(329, 42);
            this.label1.TabIndex = 15;
            this.label1.Text = "Guest Information";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lanameBox);
            this.groupBox1.Controls.Add(this.codetextBox);
            this.groupBox1.Controls.Add(this.faxtextBox);
            this.groupBox1.Controls.Add(this.wphontextBox);
            this.groupBox1.Controls.Add(this.cellPhontextBox);
            this.groupBox1.Controls.Add(this.adultstextBox);
            this.groupBox1.Controls.Add(this.undertextBox7);
            this.groupBox1.Controls.Add(this.kidstextBox6);
            this.groupBox1.Controls.Add(this.emailtextBox);
            this.groupBox1.Controls.Add(this.streettextBox);
            this.groupBox1.Controls.Add(this.citytextBox);
            this.groupBox1.Controls.Add(this.fcounttextBox);
            this.groupBox1.Controls.Add(this.faddtextBox);
            this.groupBox1.Controls.Add(this.fnameTextBox);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(1, 102);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(828, 304);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Guest Details";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lanameBox
            // 
            this.lanameBox.Location = new System.Drawing.Point(656, 28);
            this.lanameBox.Name = "lanameBox";
            this.lanameBox.Size = new System.Drawing.Size(153, 21);
            this.lanameBox.TabIndex = 30;
            // 
            // codetextBox
            // 
            this.codetextBox.Location = new System.Drawing.Point(656, 101);
            this.codetextBox.Name = "codetextBox";
            this.codetextBox.Size = new System.Drawing.Size(153, 21);
            this.codetextBox.TabIndex = 28;
            // 
            // faxtextBox
            // 
            this.faxtextBox.Location = new System.Drawing.Point(656, 141);
            this.faxtextBox.Name = "faxtextBox";
            this.faxtextBox.Size = new System.Drawing.Size(153, 21);
            this.faxtextBox.TabIndex = 27;
            // 
            // wphontextBox
            // 
            this.wphontextBox.Location = new System.Drawing.Point(656, 172);
            this.wphontextBox.Name = "wphontextBox";
            this.wphontextBox.Size = new System.Drawing.Size(153, 21);
            this.wphontextBox.TabIndex = 26;
            // 
            // cellPhontextBox
            // 
            this.cellPhontextBox.Location = new System.Drawing.Point(656, 213);
            this.cellPhontextBox.Name = "cellPhontextBox";
            this.cellPhontextBox.Size = new System.Drawing.Size(153, 21);
            this.cellPhontextBox.TabIndex = 25;
            // 
            // adultstextBox
            // 
            this.adultstextBox.Location = new System.Drawing.Point(656, 253);
            this.adultstextBox.Name = "adultstextBox";
            this.adultstextBox.Size = new System.Drawing.Size(153, 21);
            this.adultstextBox.TabIndex = 24;
            // 
            // undertextBox7
            // 
            this.undertextBox7.Location = new System.Drawing.Point(88, 253);
            this.undertextBox7.Name = "undertextBox7";
            this.undertextBox7.Size = new System.Drawing.Size(153, 21);
            this.undertextBox7.TabIndex = 23;
            // 
            // kidstextBox6
            // 
            this.kidstextBox6.Location = new System.Drawing.Point(88, 213);
            this.kidstextBox6.Name = "kidstextBox6";
            this.kidstextBox6.Size = new System.Drawing.Size(153, 21);
            this.kidstextBox6.TabIndex = 22;
            // 
            // emailtextBox
            // 
            this.emailtextBox.Location = new System.Drawing.Point(88, 175);
            this.emailtextBox.Name = "emailtextBox";
            this.emailtextBox.Size = new System.Drawing.Size(153, 21);
            this.emailtextBox.TabIndex = 21;
            // 
            // streettextBox
            // 
            this.streettextBox.Location = new System.Drawing.Point(656, 62);
            this.streettextBox.Name = "streettextBox";
            this.streettextBox.Size = new System.Drawing.Size(153, 21);
            this.streettextBox.TabIndex = 20;
            // 
            // citytextBox
            // 
            this.citytextBox.Location = new System.Drawing.Point(88, 141);
            this.citytextBox.Name = "citytextBox";
            this.citytextBox.Size = new System.Drawing.Size(153, 21);
            this.citytextBox.TabIndex = 19;
            // 
            // fcounttextBox
            // 
            this.fcounttextBox.Location = new System.Drawing.Point(88, 101);
            this.fcounttextBox.Name = "fcounttextBox";
            this.fcounttextBox.Size = new System.Drawing.Size(153, 21);
            this.fcounttextBox.TabIndex = 18;
            // 
            // faddtextBox
            // 
            this.faddtextBox.Location = new System.Drawing.Point(88, 68);
            this.faddtextBox.Name = "faddtextBox";
            this.faddtextBox.Size = new System.Drawing.Size(153, 21);
            this.faddtextBox.TabIndex = 17;
            // 
            // fnameTextBox
            // 
            this.fnameTextBox.Location = new System.Drawing.Point(88, 31);
            this.fnameTextBox.Name = "fnameTextBox";
            this.fnameTextBox.Size = new System.Drawing.Size(153, 21);
            this.fnameTextBox.TabIndex = 16;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(567, 256);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 15);
            this.label17.TabIndex = 15;
            this.label17.Text = "No Of Adults :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(2, 216);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(87, 15);
            this.label16.TabIndex = 14;
            this.label16.Text = "No. Of Kids :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(37, 178);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 15);
            this.label15.TabIndex = 13;
            this.label15.Text = "Email :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(621, 147);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 15);
            this.label14.TabIndex = 12;
            this.label14.Text = "Fax :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(28, 68);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 15);
            this.label13.TabIndex = 11;
            this.label13.Text = "Address:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(28, 107);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 15);
            this.label12.TabIndex = 10;
            this.label12.Text = "Country :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(-2, 256);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 15);
            this.label11.TabIndex = 9;
            this.label11.Text = "Under 5yrs :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(567, 178);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 15);
            this.label10.TabIndex = 8;
            this.label10.Text = "Work Phone :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(606, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 15);
            this.label8.TabIndex = 6;
            this.label8.Text = "Street :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(559, 107);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 15);
            this.label7.TabIndex = 5;
            this.label7.Text = "Zip/Post Code:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(579, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "Last Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(574, 219);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "Cell Phone :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "City :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "First Name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(460, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Existing Guest ID:";
            // 
            // cancelButton
            // 
            this.cancelButton.BackColor = System.Drawing.Color.Gray;
            this.cancelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.ForeColor = System.Drawing.Color.White;
            this.cancelButton.Location = new System.Drawing.Point(711, 412);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(118, 27);
            this.cancelButton.TabIndex = 22;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gray;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(587, 412);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 27);
            this.button3.TabIndex = 21;
            this.button3.Text = "Next";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Gray;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(463, 412);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(118, 27);
            this.button4.TabIndex = 20;
            this.button4.Text = "Back";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(587, 75);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(112, 20);
            this.textBox15.TabIndex = 31;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(705, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 27);
            this.button1.TabIndex = 32;
            this.button1.Text = "Find";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // GuestDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(841, 474);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.MaximumSize = new System.Drawing.Size(857, 513);
            this.Name = "GuestDetailsForm";
            this.Text = "Erica Hotel Reservation Form";
            this.Load += new System.EventHandler(this.GuestDetailsForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox lanameBox;
        private System.Windows.Forms.TextBox codetextBox;
        private System.Windows.Forms.TextBox faxtextBox;
        private System.Windows.Forms.TextBox wphontextBox;
        private System.Windows.Forms.TextBox cellPhontextBox;
        private System.Windows.Forms.TextBox adultstextBox;
        private System.Windows.Forms.TextBox undertextBox7;
        private System.Windows.Forms.TextBox kidstextBox6;
        private System.Windows.Forms.TextBox emailtextBox;
        private System.Windows.Forms.TextBox streettextBox;
        private System.Windows.Forms.TextBox citytextBox;
        private System.Windows.Forms.TextBox fcounttextBox;
        private System.Windows.Forms.TextBox faddtextBox;
        private System.Windows.Forms.TextBox fnameTextBox;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Button button1;
    }
}