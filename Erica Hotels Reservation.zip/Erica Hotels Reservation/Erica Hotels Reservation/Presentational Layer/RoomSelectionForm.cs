﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Erica_Hotels_Reservation.Data_Layer;
using Erica_Hotels_Reservation.Bussiness_Logic_Layer;

namespace Erica_Hotels_Reservation.Presentational_Layer
{
    public partial class RoomSelectionForm : Form
    {
        private GuestDetailsForm guestForm = new GuestDetailsForm();
        private Collection<Booking> data = new Collection<Booking>();
        public bool roomFormClosed = false;
        private RoomController roomController;
        private MainForm mainForm = new MainForm();
        //private Room room;
        
        //private MainForm anMDIForm;

        private void RoomSelection_Load(object sender, EventArgs e)
        {
            //anMDIForm.Show();
            //this.Parent = null;
            //anMDIForm = (MainForm)this.MdiParent;
            roomFormClosed = false;
            setUpRoomListView();
             
        }

        private void setUpRoomListView()
        {
            ListViewItem availableRooms;
            Collection<Room> rooms = null;
            rooms = roomController.findFreeRooms();
            //Add employee details to each ListView item 

            foreach (Room aRoom in rooms)
            {
                availableRooms = new ListViewItem(aRoom.rID);
                availableRooms.SubItems.Add(aRoom.rType);
                availableRooms.SubItems.Add(aRoom.rRate.ToString());
                availableRooms.SubItems.Add(aRoom.rStatus.ToString());
                RoomListView.Items.Add(availableRooms);
            }
            RoomListView.Refresh();

        }

        public RoomSelectionForm() 
        {
            InitializeComponent();
            roomController = new RoomController();
        }

        public RoomSelectionForm(RoomController rmController)
        {
            InitializeComponent();
            roomController = rmController;
           
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Room aRoom = new Room();
            Reservations aReservation = new Reservations();
            Guest aGuest = new Guest();
            Payments aPayment = new Payments();

            aReservation.chkIn = dateTimePick1.Value;
            aReservation.chkOut = dateTimePick2.Value;
            aReservation.RrmID = rmIdTextBox.Text.Trim();
            aRoom.rID = rmIdTextBox.Text.Trim();
            aRoom.rRate = int.Parse(rmRateTextBox.Text.Trim());
            aRoom.rType = rmTypeTextBox.Text.Trim();
            aReservation.noOfRooms = int.Parse(noOfRoomsTextBox.Text.Trim());
            this.Hide();
            guestForm.Show();


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainForm.Show();
        }



            
    }
}
