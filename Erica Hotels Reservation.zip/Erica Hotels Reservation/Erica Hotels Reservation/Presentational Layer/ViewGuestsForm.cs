﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Erica_Hotels_Reservation.Bussiness_Logic_Layer;

namespace Erica_Hotels_Reservation.Presentational_Layer
{
    public partial class ViewGuestsForm : Form
    {
        private MainForm mainForm = new MainForm();
        private GuestManagementForm guestManagementForm = new GuestManagementForm();
        public bool viewGuestFormClosed = false;
        private GuestController guestController;
        public ViewGuestsForm()
        {
            InitializeComponent();
            guestController = new GuestController();
        }

        private void ViewGuestsForm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            setUpViewGuestsListView();
            //setUpViewGuestListView();

        }
        private void setUpViewGuestsListView()
        {


            ListViewItem allGuests;
            Collection<Guest> guests = null;
            guests = guestController.FindGuests();
            //Add reservation details to each ListView item

            foreach (Guest aGuest in guests)
            {
                allGuests = new ListViewItem(aGuest.gstId);
                allGuests.SubItems.Add(aGuest.firstName);
                allGuests.SubItems.Add(aGuest.LastName);
                allGuests.SubItems.Add(aGuest.gEmail);
                allGuests.SubItems.Add(aGuest.Cphone);
                //guestslistView
                guestslistView.Items.Add(allGuests);
            }
            guestslistView.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            guestManagementForm.Show();

        }

        private void addRes_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainForm.Show();
        }

        private void viewGuests_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
