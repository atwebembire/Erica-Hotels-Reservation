﻿namespace Erica_Hotels_Reservation {
    
    
    public partial class ericaHotelReservationsDataSet {
    }
}

namespace Erica_Hotels_Reservation.ericaHotelReservationsDataSetTableAdapters {
    
    
    public partial class ReservationsTableAdapter {
    }
}
