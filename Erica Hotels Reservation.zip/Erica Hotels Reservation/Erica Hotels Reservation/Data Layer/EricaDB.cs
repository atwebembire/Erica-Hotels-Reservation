﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using Erica_Hotels_Reservation.Bussiness_Logic_Layer;

namespace Erica_Hotels_Reservation.Data_Layer
{
    public class EricaDB : DB
    {
        #region Data members

        private string tblAvailableRooms = "AvailableRooms";
        //private string tblBookedRooms = "BookedRooms";
        private string tblReservations = "Reservations";
        private string tblGuest = "Guest";
        //private string tblPayment = "Payment";
        private string tblRoomAvailability = "RoomAvailability";
        //private string tblUsers = "Users";

        private string sql_SELECT1 = "SELECT * FROM Guest";
        //private string sql_SELECT2 = "SELECT * FROM Payment";
        private string sql_SELECT3 = "SELECT * FROM Reservations";
        private string sql_SELECT4 = "SELECT * FROM AvailableRooms";
        //private string sql_SELECT5 = "SELECT * FROM BookedRooms";
        private string sql_SELECT6 = "SELECT * FROM RoomAvailability";
        //private string sql_SELECT7 = "SELECT * FROM Users";


        private Collection<Room> rooms = new Collection<Room>();
        private Collection<Reservations> reservations = new Collection<Reservations>();
        private Collection<RoomAvailability> roomAvailability = new Collection<RoomAvailability>();
        private Collection<Guest> guests = new Collection<Guest>();


        #endregion

        //Constructors
        public EricaDB()
            : base()
        {
            //Get the data from ALL 6 tables

            ReadDataFromTables(sql_SELECT1, tblGuest);
            //ReadDataFromTables(sql_SELECT2, tblPayment);
            ReadDataFromTables(sql_SELECT4, tblAvailableRooms);
            ReadDataFromTables(sql_SELECT3, tblReservations);

            //ReadDataFromTables(sql_SELECT5, tblBookedRooms);
            ReadDataFromTables(sql_SELECT6, tblRoomAvailability);
            //ReadDataFromTables(sql_SELECT7, tblUsers);

        }
        public Collection<Room> allRooms
        {
            get { return rooms; }
        }
        public Collection<Guest> allGuests
        {
            get { return guests; }
        }
        public Collection<Reservations> allReservations
        {
            get { return reservations; }
        }
        public Collection<RoomAvailability> checkAvailables
        {
            get { return roomAvailability; }
        }
        #region Data reader
        private string ReadDataFromTables(string selectString, string aTable)
        {
            SqlDataReader aReader;
            SqlCommand command;
            try
            {
                command = new SqlCommand(selectString, mainConnection);
                mainConnection.Open();                                                                  //open the connection
                command.CommandType = CommandType.Text;
                aReader = command.ExecuteReader();                                 //Read from table
                if (aReader.HasRows)
                {
                    FillTables(aReader, aTable, rooms);       //Fill the collection – 
                }
                aReader.Close();   //close the reader 
                mainConnection.Close();  //close the connection
                return "success";
            }
            catch (Exception ex)
            {
                return (ex.ToString());
            }

        }
        #endregion


        private void FillTables(SqlDataReader aReader, string aTable, Collection<Room> rooms)
        {
            Room aRoom;
            Reservations aReservation;
            RoomAvailability aRoomCheck;
            Guest aGuest;
            switch (aTable)
            {

                case "Reservations":

                    while (aReader.Read())
                    {
                        aReservation = new Reservations();
                        aReservation.guestNm = aReader["guestName"].ToString();
                        aReservation.resID = aReader["reservationId"].ToString();
                        aReservation.resStatus = aReader["Status"].ToString();
                        aReservation.RrmID = aReader["roomId"].ToString();
                        aReservation.chkIn = (DateTime)aReader["CheckIn"];
                        aReservation.chkOut = (DateTime)aReader["CheckOut"];
                        reservations.Add(aReservation);

                    }

                    break;
                case "AvailableRooms":

                    while (aReader.Read())        //Read while you can
                    {
                        aRoom = new Room();
                        aRoom.rID = aReader["roomId"].ToString();
                        aRoom.rType = aReader["roomType"].ToString();
                        aRoom.rRate = (double)aReader["roomRate"];
                        aRoom.rStatus = aReader["roomStat"].ToString();
                        rooms.Add(aRoom);
                    }
                    break;
                case "RoomAvailability":

                    while (aReader.Read())        //Read while you can
                    {
                        aRoomCheck = new RoomAvailability();
                        aRoomCheck.chkRmAvail = (DateTime)aReader["dates"];
                        roomAvailability.Add(aRoomCheck);

                    }

                    break;
                case "Guest":

                    while (aReader.Read())        //Read while you can
                    {

                        aGuest = new Guest();
                        aGuest.firstName = aReader["firstname"].ToString();
                        aGuest.LastName = aReader["lastname"].ToString();
                        aGuest.gstId = aReader["guestId"].ToString();
                        aGuest.gEmail = aReader["email"].ToString();
                        aGuest.Cphone = aReader["mobilephone"].ToString();
                        //aGuest.gCity = aReader["city"].ToString();
                        //aGuest.gcounTry = aReader["country"].ToString();
                        //aGuest.adR = aReader["adress"].ToString();
                       
                        //aGuest.gFax = aReader["fax"].ToString();
                        //aGuest.Pcode = aReader["postcode"].ToString();
                        //aGuest.gStreet = aReader["street"].ToString();
                        //aGuest.Wphone = aReader["workphone"].ToString();
                        guests.Add(aGuest);

                    }
                    break;



            }

            #region DataGridView Database Access

            #endregion

        }

    }
}

