﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class BookingController
    {
    }
}
