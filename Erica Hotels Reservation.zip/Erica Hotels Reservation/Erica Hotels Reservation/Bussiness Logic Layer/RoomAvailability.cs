﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class RoomAvailability
    {
        private Collection<RoomAvailability> checkRoomAvailability = new Collection<RoomAvailability>();

        private DateTime chkRmAvailab;

        public DateTime chkRmAvail
        {
            get
            {
                return chkRmAvailab;

            }
            set
            {
                chkRmAvailab = value;
            }
        }

        
    }
}
