﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Erica_Hotels_Reservation.Data_Layer;

using System.Linq;
using System.Text;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class AvailabilityController
    {
        private EricaDB rmAvailDB;
        private Collection<RoomAvailability> roomCheck;

        public AvailabilityController()
        {
            rmAvailDB = new EricaDB();
            roomCheck = rmAvailDB.checkAvailables;
        }
        public Collection<RoomAvailability> checkAvailables
        {
            get
            {
                return roomCheck;
            }
        }
        #region Add, Edit,Delete, View from Collection and Database

        public void Add(RoomAvailability aRoomCheck)
        {
            roomCheck.Add(aRoomCheck);
            //.Add(aRoomCheck);
            //DataBaseADD(aRoom);

        }

        private void DataBaseADD(Room aRoom)
        {
            //rmDB.DatabaseAdd(aRoom);
        }
        public void Edit(Room aRoom)
        {

        }
        public void Delete(Room aRoom)
        {

        }
        #endregion

        #region Database Lookups
        public Collection<RoomAvailability> CheckRooms()
        {
            Collection<RoomAvailability> dateMatch = new Collection<RoomAvailability>();

            foreach (RoomAvailability roomCheck in checkAvailables)
            {
                if (roomCheck.chkRmAvail != null)
                {
                dateMatch.Add(roomCheck);
                }
            }
            return dateMatch;
        }
        #endregion

    }
}
