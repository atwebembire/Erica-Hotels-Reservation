﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Erica_Hotels_Reservation.Data_Layer;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class ResMgtContoller
    {
        EricaDB resFill = new EricaDB();
        public void FillResGridView() 
        {
           // resFill
        }
    }

}
