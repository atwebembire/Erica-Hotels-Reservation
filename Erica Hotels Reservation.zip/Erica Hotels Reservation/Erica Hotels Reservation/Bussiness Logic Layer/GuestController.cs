﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using Erica_Hotels_Reservation.Data_Layer;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class GuestController
    {

        //private int count = 0;
        private EricaDB guestDB;
        private Collection<Guest> guests;
      
        public GuestController()
        {
           guestDB = new EricaDB();
            guests = guestDB.allGuests;
        }
        public Collection<Guest> allGuests
        {
            get
            {
                return guests;
            }
        }
        #region Add, Edit,Delete, View from Collection and Database

        public void Add(Guest aGuest)
        {
            guests.Add(aGuest);
            //DataBaseADD(aReservation);

        }

        #endregion
        #region Database Lookups
        public Collection<Guest> FindGuests()
        {
            Collection<Guest> allgs = new Collection<Guest>();
      
            foreach (Guest guests in allGuests)
            {
                if (guests.gstId != null )
                {
                    //count += 1;
                    
                    allgs.Add(guests);
                }
          
            }
            //MessageBox.Show("This is guests" + count);
            return allgs;
        }
        #endregion
         
    }
}
