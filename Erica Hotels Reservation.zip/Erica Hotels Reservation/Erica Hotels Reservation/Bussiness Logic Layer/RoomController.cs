﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Erica_Hotels_Reservation.Data_Layer;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class RoomController
    {
        private EricaDB rmDB;
        private Collection<Room> rooms;

        public RoomController() 
        {
            rmDB = new EricaDB();
            rooms = rmDB.allRooms;
        }
        public Collection<Room> allRooms 
        {
            get
            {
                return rooms;
            }
        }
        #region Add, Edit,Delete, View from Collection and Database

        public void Add(Room aRoom) 
        {
            rooms.Add(aRoom);
            DataBaseADD(aRoom);

        }

        private void DataBaseADD(Room aRoom)
        {
            //rmDB.DatabaseAdd(aRoom);
        }
        public void Edit(Room aRoom) 
        {

        }
        public void Delete(Room aRoom) 
        {
            
        }
        #endregion

        #region Database Lookups
        public Collection<Room> findFreeRooms()
        {
            Collection<Room> matches = new Collection<Room>();

            foreach (Room rooms in allRooms)
            {
                if (rooms.rStatus == "available")
                {
                    matches.Add(rooms);
                }
            }
            return matches;
        }
        #endregion

        
    }
}
