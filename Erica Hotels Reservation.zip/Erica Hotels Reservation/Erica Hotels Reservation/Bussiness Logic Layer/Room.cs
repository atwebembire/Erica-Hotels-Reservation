﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class Room
    {
        #region Data members
        private string rmID;
        private string rmType;
        private double rmRate;
        private double rmPackages;
        private double rmXcharges;
        private string rmStatus;
        #endregion

        #region properties
        public string rID
        {
            get
            {
                return rmID;
            }
            set
            {
                rmID = value;
            }
        }
        public string rType
        {
            get
            {
                return rmType;
            }
            set
            {
                rmType = value;
            }
        }
        public double rRate 
        {
            get 
            {
                return rmRate;
            }
            set 
            {
                rmRate = value;
            }
        }
        public double rPackages
        {
            get
            {
                return rmPackages;
            }
            set
            {
                rmPackages = value;
            }
        }
        public double rXcharges
        {
            get
            {
                return rmXcharges;
            }
            set
            {
                rmXcharges = value;
            }
        }
        public string rStatus
        {
            get
            {
                return rmStatus;
            }
            set
            {
                rmStatus = value;
            }
        }
        #endregion
        
    }
}
