﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class Reservations
    {
        #region Data members

        private string reservationId;
        private string roomId;
        private string guestName;
        private DateTime checkIn;
        private DateTime checkOut;
        private string status;
        public int noOfRooms;
        public int noOfAdults;
        public int noOfKids;
        #endregion

        #region Properties
        public string resID
        {
            get
            {
                return reservationId;
            }
            set
            {
                reservationId = value;
            }
        }
        public string RrmID
        {
            get
            {
                return roomId;
            }
            set
            {
                roomId = value;
            }
        }
        public string guestNm
        {
            get
            {
                return guestName;
            }
            set
            {
                guestName = value;
            }
        }
        public string resStatus
        {
            get
            {
                return status;
            }
            set
            {
                status = value;
            }
        }
        public DateTime chkIn
        {
            get
            {
                return checkIn;
            }
            set
            {
                checkIn = value;
            }
        }
        public DateTime chkOut
        {
            get
            {
                return checkOut;
            }
            set
            {
                checkOut = value;
            }
        }
        public int nrooms
        {
            get
            {
                return noOfRooms;
            }
            set
            {
                noOfRooms = value;
            }
        }
        public int nAdults
        {
            get
            {
                return noOfAdults;
            }
            set
            {
                noOfAdults = value;
            }
        }
        public int nKids
        {
            get
            {
                return noOfKids;
            }
            set
            {
                noOfKids = value;
            }
        }
       




        #endregion

    }
}
