﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class Guest
    {


        #region Date members 
        private string fname;
        private string lname;
        //private string address;
        //private string country;
        //private string city;
        //private string street;
        private string email;
        private string cellPhone;
        //private string workPhone;
        //private string postCode;
        //private string fax;
        private string guestId;
        #endregion
        public string gstId
        {
            get
            {
                return guestId;
            }
            set
            {
                guestId = value;
            }
        }
        //public string Pcode
        //{
        //    get
        //    {
        //        return postCode;
        //    }
        //    set
        //    {
        //        postCode = value;
        //    }
        //}
        //public string Wphone
        //{
        //    get
        //    {
        //        return workPhone;
        //    }
        //    set
        //    {
        //            workPhone = value;
        //    }
        //}
        public string Cphone
        {
            get
            {
                return cellPhone;
            }
            set
            {
                cellPhone = value;
            }
        }
        public string gEmail
        {
            get
            {
                return email;
            }
            set
            {
                email = value;
            }
        }
        //public string gStreet
        //{
        //    get
        //    {
        //        return street;
        //    }
        //    set
        //    {
        //        street = value;
        //    }
        //}
        //public string gCity
        //{
        //    get
        //    {
        //        return city;
        //    }
        //    set
        //    {
        //        city = value;
        //    }
        //}
        public string firstName
        {
            get
            {
                return fname;
            }
            set
            {
                fname = value;
            }
        }
        public string LastName
        {
            get
            {
                return lname;
            }
            set
            {
                lname = value;
            }
        }
        //public string adR
        //{
        //    get
        //    {
        //        return address;
        //    }
        //    set
        //    {
        //        address = value;
        //    }
        //}
        //public string gcounTry
        //{
        //    get
        //    {
        //        return country;
        //    }
        //    set
        //    {
        //        country= value;
        //    }
        //}
        //public string gFax
        //{
        //    get
        //    {
        //        return fax;
        //    }
        //    set
        //    {
        //        fax = value;
        //    }
        //}







    }
}
