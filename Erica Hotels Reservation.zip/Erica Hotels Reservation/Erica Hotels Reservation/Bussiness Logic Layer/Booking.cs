﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class Booking
    {
        /*
        private string checkInDate;
        private string checkOutDate;
        private string roomId;
        private string noOfRooms;
  
         */


    }
}
