﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Erica_Hotels_Reservation.Data_Layer;

namespace Erica_Hotels_Reservation.Bussiness_Logic_Layer
{
    public class ReservationController
    {
        
        private EricaDB resDB;
        private Collection<Reservations> reservations;

        public ReservationController()
        {
            resDB = new EricaDB();
            reservations = resDB.allReservations;
        }
        public Collection<Reservations> allReservations
        {
            get
            {
                return reservations;
            }
        }
        #region Add, Edit,Delete, View from Collection and Database

        public void Add(Reservations aReservation)
        {
            reservations.Add(aReservation);
            //DataBaseADD(aReservation);

        }

        #endregion
        #region Database Lookups
        public Collection<Reservations> FindReservation()
        {
         
            Collection<Reservations> allOfthem = new Collection<Reservations>();
      
            foreach (Reservations reservations in allReservations)
            {
              
                if (reservations.resStatus != null)
                {
                    
                    allOfthem.Add(reservations);
                }
         
            }
            
            return allOfthem;        
        }
        #endregion
    }
}
